<!--Developed BY CALL360 WEBSTUDIO DIVISION OF CALL360 IT SERVICES PVT LTD.-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<h3>ENQUIRY SUBMITTED SUCCESSFULLY <br/> OUR EXECUTIVE CONTACT YOU SHORTLY </h3>
<?php
/*Developed BY CALL360 WEBSTUDIO DIVISION OF CALL360 IT SERVICES PVT LTD.*/
sleep(3);
if(isset($_POST['name']))
{
$fname = $_POST['name'];
$femail = $_POST['email'];
$fsubject = $_POST['subject'];
$fmessage = $_POST['message'];
/*Developed BY CALL360 WEBSTUDIO DIVISION OF CALL360 IT SERVICES PVT LTD.*/
$to = "gunadmtdomains@gmail.com";
$subject = "Lead From WebSite";
$txt = '
<html>
<head>
<title>HTML email</title>
</head>
<body>
<table width="550" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2" style="background-color:#d5ffb3" align="center"><h3>DEANFORMULATION CONTACT</h3></td>
  </tr>
  <tr>
    <td width="275">NAME :</td>
    <td>'.$fname.'</td>
  </tr>
  <tr style="background-color:#d5ffb3">
    <td>MOBILE :</td>
    <td>'.$femail.'</td>
  </tr>
  <tr>
    <td>SUBJECT :</td>
    <td>'.$fsubject.'</td>
  </tr>
  <tr style="background-color:#d5ffb3">
    <td>FROM PAGE :</td>
    <td>"WEBSITE CONTACT PAGE"</td>
  </tr>
  <tr>
    <td>MESSAGE :</td>
    <td>'.$fmessage.'</td>
  </tr>
</table>

</body>
</html>';
/*Developed BY CALL360 WEBSTUDIO DIVISION OF CALL360 IT SERVICES PVT LTD.*/
$headers .= "From: enquiry@deanformulations.com" . "\r\n";
$headers .= 'Bcc: gunadmtdomains@gmail.com' . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\b";
/*Developed BY CALL360 WEBSTUDIO DIVISION OF CALL360 IT SERVICES PVT LTD.*/
mail($to,$subject,$txt,$headers);
}
?>
<?php
  header("Location: http://deanformulations.com/demo/index.html");
?>

</body>
</html>














<!--Developed BY CALL360 WEBSTUDIO DIVISION OF CALL360 IT SERVICES PVT LTD.-->
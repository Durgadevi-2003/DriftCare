<!DOCTYPE html>
<html lang="en">

<head>
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="../../../../stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css">
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Contact - Eterna Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Eterna - v4.7.1
  * Template URL: https://bootstrapmade.com/eterna-free-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
<?php 
  // Starts the session
  session_start();

// Check Login form submitted
  if(isset($_POST['Submit'])){
  
  
  // Define username and associated password array
  $logins = array('admin' => 'admin', 'Stanley' => 'admin26', 'administrator' => 'admin1234');

// Check and assign submitted user_name and password to new variable
  $user_name = isset($_POST['user_name']) ? $_POST['user_name'] : '';
  $password = isset($_POST['password']) ? $_POST['password'] : '';
// Check user_name and password existence in defined array
  if (isset($logins[$user_name]) && $logins[$user_name] == $password){
  
  // Success: Set session variables and redirect to Protected page
  $_SESSION['UserData']['admin']=$logins[$user_name];
  header("location:index.html");
  exit;
  }
  elseif {
  
  // Success: Set session variables and redirect to Protected page
  $_SESSION['UserData']['Stanley']=$logins[$user_name];
  header("location:index26.html");
  exit;
  }


  else {
  
  
  // Unsuccessful attempt: Set error message
  $msg="<span style='color:red'>Invalid Login Details</span>";
  }
  }
?>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:contact@example.com">info@deanformulations.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+91 7904888397</span></i>
      </div>
      <div class="social-links d-none d-md-flex align-items-center">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex justify-content-between align-items-center">

      <div class="logo1">
        <h1><img src="assets/img/Deanformulations-logo.png" alt="Deanformulations-logo" /></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li class="dropdown"><a class="active" href="#"><span>Products</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li class="dropdown"><a href="#"><span>Products-I</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deepan 40</a></li>
                  <li><a href="#">Deepan DSR</a></li>
                  <li><a href="#">Raidean 20</a></li>
                  <li><a href="#">Raidean DSR</a></li>
                  <li><a href="#">Deenac SP</a></li>
                  <li><a href="#">Diloser GEL</a></li>
                  <li><a href="#">Gairon SUSP</a></li>
                  <li><a href="#">DEENAC P</a></li>
                  <li><a href="#">DEFY TA</a></li>
                  <li><a href="#">DELIMIT G1</a></li>
                </ul>
              <li class="dropdown"><a href="#"><span>Products-II</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Gairon XT</a></li>
                  <li><a href="#">ADD- SOFTGEL Cap</a></li>
                  <li><a href="#">Folkoz SOFTGEL Cap</a></li>
                  <li><a href="#">INOCYST</a></li>
                  <li><a href="#">Inocyst PLUS</a></li>
                  <li><a href="#">Caldean</a></li>
                  <li><a href="#">CHYMOTEL FORTE</a></li>
                  <li><a href="#">Diloser tab</a></li>
                  <li><a href="#">LUCOS LM</a></li>
                  <li><a href="#">DELIMIT G2</a></li>
                </ul>
              </li>
            </ul>
          </li>
          <li><a href="#">HRD</a></li>
          <li><a href="careers.html">Career</a></li>
          <li><a href="contact.html">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="index.html">Home</a></li>
          <li>HRD Login</li>
        </ol>
        <h2>HRD </h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">
<section class="ftco-section">
<div class="container">
<div class="row justify-content-center">
<div class="col-md-6 text-center mb-5">
<h2 class="heading-section">Login #065</h2>
</div>
</div>
<div class="row justify-content-center">
<div class="col-md-12 col-lg-10">
<div class="wrap d-md-flex">
<div class="img" style="background-image: url(assets/img/login-caution.jpg);">
</div>
<div class="login-wrap p-4 p-md-5">
<div class="d-flex">
<div class="w-100">
<h3 class="mb-4">Sign In</h3>
</div>
<div class="w-100">
<p class="social-media d-flex justify-content-end">
<a href="#" class="social-icon d-flex align-items-center justify-content-center"><span class="fa fa-facebook"></span></a>
<a href="#" class="social-icon d-flex align-items-center justify-content-center"><span class="fa fa-twitter"></span></a>
</p>
</div>
</div>
<form action="" method="POST" name="Login_Form" class="signin-form">
<div class="form-group mb-3">
<label class="label" for="name">Username</label>
<input name="user_name" type="text" class="form-control" placeholder="Username" required>
</div>
<div class="form-group mb-3">
<label class="label" for="password">Password</label>
<input type="password" name="password" class="form-control" placeholder="Password" required>
</div>
<div class="form-group">
<button type="submit" name="Submit" value="Login" class="form-control btn btn-primary rounded submit px-3">Sign In</button>
</div>
<div class="form-group d-md-flex">
<div class="w-50 text-left">
<label class="checkbox-wrap checkbox-primary mb-0">Remember Me
<input type="checkbox" checked>
<span class="checkmark"></span>
</label>
</div>
<div class="w-50 text-md-right">
<a href="#" data-toggle="modal" data-target="#myModal">Forgot Password</a>
</div>
</div>
</form>
<p class="text-center">Not a member? <a data-toggle="tab" href="#signup">Sign Up</a></p>
</div>
</div>
</div>
</div>
</div>
</section>
<script src="js/jquery.min.js"></script>
<script src="js/popper.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vaafb692b2aea4879b33c060e79fe94621666317369993" integrity="sha512-0ahDYl866UMhKuYcW078ScMalXqtFJggm7TmlUtp0UlD4eQk0Ixfnm5ykXKvGJNFjLMoortdseTfsRT8oCfgGA==" data-cf-beacon='{"rayId":"7a007067dfc69a8d","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2023.2.0","si":100}' crossorigin="anonymous"></script>
      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

 <!-- ======= Footer ======= -->
  <footer id="footer">

   

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Products</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Careers</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Contact</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Top Products</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">INOCYST</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">GAIRON XT</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">DEOPAN-40</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">CALDEAN</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">DEENAC SP</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              NO 39, PADMAVATHY NAGAR,<br>
              NRS ROAD, KORATTUR<br>
              CHENNAI - 76, TAMIL NADU, INDIA<br><br>
              <strong>Phone:</strong> +91 7904888397<br>
              <strong>Email:</strong> info@deanformulations.com<br>
            </p>

          </div>

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>About Deanformulations</h3>
            <p>Deanformulation Pharmaceutical company is a leader in the industry, providing innovative solutions and products to meet the needs of customers.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Eterna</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        
        Designed by <a href="https://bootstrapmade.com/">Freelance webDesigner Chennai</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>
<!-- model content starts here-->
<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">DEANFORMULATIONS</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
          <p>Don't panic, we are here to help you, drop a mail to hr@deanformulations.com with your employee ID. Thank you!..</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<!-- model content ends here-->
</html>
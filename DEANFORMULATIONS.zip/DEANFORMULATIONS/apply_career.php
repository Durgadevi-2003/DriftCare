<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dean Formulations Pvt. Ltd.</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Eterna - v4.7.1
  * Template URL: https://bootstrapmade.com/eterna-free-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:contact@example.com">info@deanformulations.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+91 7904888397</span></i>
      </div>
      <div class="social-links d-none d-md-flex align-items-center">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex justify-content-between align-items-center">

      <div class="logo1">
        <h1><a href="index.html"><img src="assets/img/Deanformulations-logo.png" alt="Deanformulations-logo" /></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li class="dropdown"><a href="#"><span>Products</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li class="dropdown"><a href="#"><span>Products-I</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="product-deepan-40.html">Deepan 40</a></li>
                  <li><a href="#">Deepan DSR</a></li>
                  <li><a href="#">Raidean 20</a></li>
                  <li><a href="#">Raidean DSR</a></li>
                  <li><a href="#">Deenac SP</a></li>
                  <li><a href="#">Diloser GEL</a></li>
                  <li><a href="#">Gairon SUSP</a></li>
                  <li><a href="#">DEENAC P</a></li>
                  <li><a href="#">DEFY TAB</a></li>
                  <li><a href="#">DELIMIT G1</a></li>
                </ul>
                <li class="dropdown"><a href="#"><span>Products-II</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Gairon XT</a></li>
                  <li><a href="#">ADD- SOFTGEL Cap</a></li>
                  <li><a href="#">Folkoz SOFTGEL Cap</a></li>
                  <li><a href="#">INOCYST</a></li>
                  <li><a href="#">Inocyst PLUS</a></li>
                  <li><a href="#">Caldean</a></li>
                  <li><a href="#">CHYMOTEL FORTE</a></li>
                  <li><a href="#">Diloser tab</a></li>
                  <li><a href="#">LUCOS LM</a></li>
                  <li><a href="#">DELIMIT G2</a></li>
                </ul>
              </li>
            </ul>
          </li>
          <li><a href="#">HRD</a></li>
          <li><a class="active" href="#">Career</a></li>
          <li><a href="contact.html">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <!-- Slide 1 -->
          <div class="carousel-item active" style="background-image: url(assets/img/slide/careers-banner-image.jpg)">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Deanformulations <span> Pvt. Ltd.</span></h2>
                             </div>
            </div>
          </div>

          <!-- Slide 2 -->
          <div class="carousel-item" style="background-image: url(assets/img/slide/careers-banner-image.jpg)">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Deanformulations <span> Pvt. Ltd.</span></h2>
               </div>
            </div>
          </div>

          <!-- Slide 3 -->
          <div class="carousel-item" style="background-image: url(assets/img/slide/careers-banner-image.jpg)">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Deanformulations <span> Pvt. Ltd.</span></h2>
               </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>

      </div>
    </div>
  </section><!-- End Hero -->


  <div class="row">
  <div class="col-lg-5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="assets/img/portfolio/join_with_us.gif" alt="deanformulations careers" /></div>
  <div class="col-lg-5"><form method="post" action="php-lib/dean-contact.php" id="contactForm" name="contactForm" class="contactForm">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
               <div class="row">
                <div class="col-md-6 form-group"><br/>
                  <input type="text" name="name" class="form-control" id="name" placeholder="Date of Birth DD/MM/YYYY" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0"><br/>
                  <select class="form-control form-control-sm">
  <option>SELECT YOUR GENDER</option>
    <option value="male">MALE</option>
      <option value="female">FEMALE</option>
</select>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="radio" class="form-check-input" id="radio1" name="optradio" value="AIR FREIGHT" >
      			<label class="form-check-label" for="radio1">FRESHER</label>
                <input type="radio" class="form-check-input" id="radio1" name="optradio" value="OCEAN FREIGHT" >
      			<label class="form-check-label" for="radio2">EXPERIENCED</label><br/>
              </div><br/>
              <div class="row">
                <div class="col-md-6 form-group">
                  <select class="form-control form-control-sm">
  <option>SELECT YOUR EXPERIENCE</option>
    <option value="male">1+</option>
      <option value="female">2+</option>
</select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Mobile" required><br/>
                </div>
              </div>
                            <div class="row">
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Current CTC" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Expected CTC" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="COMMUNICATION ADDRESS" required></textarea>
              </div>
               <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="PERMANENT ADDRESS" required></textarea>
              </div><br/>
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="file" class="form-control-file" id="exampleFormControlFile1">
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <img src="assets/img/portfolio/file_formats.gif" alt="pdf &amp; doc" />Only pdf,docx &amp; doc accept 
                </div>
              </div>

              <div class="text-center"><button type="submit">Send Message</button></div>
            </form></div>
   

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

   

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Products</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Careers</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Contact</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Top Products</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">INOCYST</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">GAIRON XT</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">DEOPAN-40</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">CALDEAN</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">DEENAC SP</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              NO 39, PADMAVATHY NAGAR,<br>
              NRS ROAD, KORATTUR<br>
              CHENNAI - 76, TAMIL NADU, INDIA<br><br>
              <strong>Phone:</strong> +91 7904888397<br>
              <strong>Email:</strong> info@deanformulations.com<br>
            </p>

          </div>

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>About Deanformulations</h3>
            <p>Deanformulation Pharmaceutical company is a leader in the industry, providing innovative solutions and products to meet the needs of customers.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Eterna</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        
        Designed by <a href="https://bootstrapmade.com/">Freelance webDesigner Chennai</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>